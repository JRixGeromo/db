<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Button extends Field
{
}
