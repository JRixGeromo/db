<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Toggle extends Checkbox
{
}
