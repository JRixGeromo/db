<?php defined('ABSPATH') || exit; ?>

<div class="glsr-reviews-wrap">
    <div class="{{ class }}">
        {{ reviews }}
    </div>
    {{ pagination }}
</div>
