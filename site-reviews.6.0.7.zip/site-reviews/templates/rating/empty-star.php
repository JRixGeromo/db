<span class="{{ prefix }}star {{ prefix }}star-empty" aria-hidden="true"></span>
