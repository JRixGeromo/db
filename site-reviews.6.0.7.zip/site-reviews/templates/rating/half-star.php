<span class="{{ prefix }}star {{ prefix }}star-half" aria-hidden="true"></span>
