<div class="{{ prefix }}star-rating {{ prefix }}stars" data-rating="{{ rating }}">
    <span class="screen-reader-text">{{ title }}</span>
    {{ full_stars }}{{ half_stars }}{{ empty_stars }}
</div>
