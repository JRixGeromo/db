<span class="{{ prefix }}star {{ prefix }}star-full" aria-hidden="true"></span>
