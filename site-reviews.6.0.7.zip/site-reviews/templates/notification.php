<?php defined('ABSPATH') || exit; ?>

<strong>A new {review_rating}-star review has been submitted:</strong>

{review_title}

{review_content}

{review_author} &lt;{review_email}&gt; - {review_ip}

{review_link}
