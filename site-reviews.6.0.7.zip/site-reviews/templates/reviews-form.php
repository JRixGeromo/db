<?php defined('ABSPATH') || exit; ?>

<div class="glsr-form-wrap">
    <form class="{{ class }}" method="post" enctype="multipart/form-data">
        {{ fields }}
        {{ response }}
        {{ submit_button }}
    </form>
</div>
