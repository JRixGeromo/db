<?php defined('ABSPATH') || exit; ?>

<div class="glsr-summary-wrap">
    <div class="{{ class }}">
        {{ rating }}
        {{ stars }}
        {{ text }}
        {{ percentages }}
    </div>
</div>
