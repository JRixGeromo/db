<?php defined('ABSPATH') || exit; ?>

<div class="{{ class }}" data-field="{{ field_name }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</div>
