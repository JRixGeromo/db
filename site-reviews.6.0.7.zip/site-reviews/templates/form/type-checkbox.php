<?php defined('ABSPATH') || exit; ?>

<span class="{{ class }}">
    <label for="{{ id }}">
        <span>{{ input }}&#8203;</span> <!-- zero-space character used for alignment -->
        <span>{{ text }}</span>
    </label>
</span>
