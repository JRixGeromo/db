<?php defined('ABSPATH') || exit; ?>

<div class="{{ class }}">{{ errors }}</div>
