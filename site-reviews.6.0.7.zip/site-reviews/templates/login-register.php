<?php defined('ABSPATH') || exit; ?>

<div class="glsr-login-register">
    <p>{{ text }}</p>
</div>
